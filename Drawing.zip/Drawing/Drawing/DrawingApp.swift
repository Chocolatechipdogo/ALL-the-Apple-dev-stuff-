//
//  DrawingApp.swift
//  Drawing
//
//  Created by csuftitan on 4/16/23.
//

import SwiftUI

@main
struct DrawingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
