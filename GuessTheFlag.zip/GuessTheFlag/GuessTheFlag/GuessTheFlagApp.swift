//
//  GuessTheFlagApp.swift
//  GuessTheFlag
//
//  Created by csuftitan on 3/8/23.
//

import SwiftUI

@main
struct GuessTheFlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
