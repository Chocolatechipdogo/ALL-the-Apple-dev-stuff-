//
//  ContentView.swift
//  GuessTheFlag
//
//  Created by csuftitan on 3/8/23.
//

import SwiftUI

struct ContentView: View {
    //    @State private var showingAlert = false
    @State private var countries = ["Estonia", "France", "Germany", "Ireland", "Italy", "Nigeria", "Poland", "Russia", "Spain", "UK", "US"].shuffled()
    @State private var correctAnswer = Int.random(in: 0...2)
    
    @State private var showingScore = false
    @State private var scoreTitle = ""
    @State private var scoreTracker = 0
    @State private var guessingCorretly = false
    var body: some View {
        //        ZStack{
        //            VStack(spacing: 0){
        //                Color(.green)
        //                Color(.systemPink)
        //            }
        //
        ////                .frame(minWidth: 200.0, maxWidth: .infinity, maxHeight: 200)
        //            Text("Your Content")
        //                .foregroundColor(.secondary)
        //                .padding(50)
        //                .background(.ultraThinMaterial)
        //            LinearGradient(gradient: Gradient(colors: [.red, .green]), startPoint: .top, endPoint: .bottom)
        //            RadialGradient(gradient: Gradient(colors: [.blue, .init(red: 0.3, green: 0.2, blue: 0.75)]), center: .center, startRadius: 20, endRadius: 200)
        //            AngularGradient(gradient: Gradient(colors: [.red, .yellow, .green, .blue, .purple, .red]), center: .center)
        
        //prominet buttons
        //            VStack {
        //                Button("Button 1") { }
        //                    .buttonStyle(.bordered)
        //                Button("Button 2", role: .destructive) { }
        //                    .buttonStyle(.bordered)
        //                Button("Button 3") { }
        //                    .buttonStyle(.borderedProminent)
        //                    .tint(.mint)
        //                Button("Button 4", role: .destructive) { }
        //                    .buttonStyle(.borderedProminent)
        //            }
        
        //custom label
        //            Button {
        //                print("Button was tapped")
        //            } label: {
        //                Text("Tap me!")
        //                    .padding()
        //                    .foregroundColor(.white)
        //                    .background(.red)
        //            }
        //how to add images to button that in the apple system
        //            Button {
        //                print("Edit button was tapped")
        //            } label: {
        //                Image(systemName: "pencil")
        //            }
        //to add other images do Image("pencil") where the "" is the name of the image
        //another version is Image(systemName: "pencil") which will just not state the name of the image
        //to fix color issues: renderingMode(.original)
        
        //button with image and text
        //            Button {
        //                print("Edit button was tapped")
        //            } label: {
        //                Label("Edit", systemImage: "pencil")
        //            }
        
        
        //alert section
        
        //                    Button("Show Alert") {
        //                        showingAlert = true
        //                    }
        //                    .alert("Important message", isPresented: $showingAlert) {
        //                        Button("OK") { }
        //                    }
        
        
        
        
        
        
        
        //        }
        //        .ignoresSafeArea()
        ZStack{
            RadialGradient(stops: [
                .init(color: Color(red: 0.1, green: 0.2, blue: 0.45), location: 0.3),
                .init(color: Color(red: 0.76, green: 0.4, blue: 0.76), location: 0.3),
            ], center: .top, startRadius: 200, endRadius: 400)
            .ignoresSafeArea()
            VStack{
                Spacer()
                Text("Guess the Flag")
                    .font(.largeTitle.bold())
                        .foregroundColor(.white)
                
            VStack(spacing: 15) {
                VStack {
                    Text("Tap the flag of")
                        .font(.subheadline.weight(.heavy))
                        .foregroundStyle(.secondary)
                    
                    Text(countries[correctAnswer])
                        .font(.largeTitle.weight(.semibold))
                        
                }
                
                ForEach(0..<3) { number in
                    Button {
                        flagTapped(number)
                    } label: {
                        Image(countries[number])
                            .renderingMode(.original)
                            .clipShape(Capsule())
                            .shadow(radius: 5)
                    }
                }
            }
                Spacer()
                Spacer()
                Text("Score: \(scoreTracker)")
                    .foregroundColor(.white)
                    .font(.title.bold())
                Spacer()
        }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 20)
            .background(.regularMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .alert(scoreTitle, isPresented: $showingScore) {
                Button("Continue", action: askQuestion)
            } message: {
                Text("Score: \(scoreTracker) ")
            }
            .padding()
    }
}
    
    func flagTapped(_ number: Int) {
        if number == correctAnswer {
            scoreTitle = "Correct"
            
            if(guessingCorretly){
                scoreTracker *= 2
            }
            else{
                scoreTracker += 100
            }
            
            guessingCorretly = true
            
        } else {
            scoreTitle = "Wrong"
            guessingCorretly = false
        }

        showingScore = true
    }
    
    func askQuestion() {
        countries.shuffle()
        correctAnswer = Int.random(in: 0...2)
    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
