//
//  ship.swift
//  BattleShipStudy
//
//  Created by csuftitan on 5/14/23.
//

import UIKit

struct Ship{
    let length: Int
    var coordinates: [(x: Int, y: Int)]
}
