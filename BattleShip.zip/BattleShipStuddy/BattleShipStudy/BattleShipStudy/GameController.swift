//
//  GameController.swift
//  BattleShipStudy
//
//  Created by csuftitan on 5/14/23.
//

import UIKit

class GameController {
    let gridButtons: [[UIButton]]
    var ships: [Ship]
    var playerShips:[Ship]
    
    
    init(gridButtons: [[UIButton]]) {
        self.gridButtons = gridButtons
        self.ships = []
        self.playerShips = []
    }
}

extension GameController{
    func placeShip(_ ship: Ship) -> Bool {
            for coordinate in ship.coordinates {
                let button = gridButtons[coordinate.x][coordinate.y]
                if button.tag == 1 {
                    return false
                }
            }
            
            for coordinate in ship.coordinates {
                let button = gridButtons[coordinate.x][coordinate.y]
                button.tag = 1
            }
            
            ships.append(ship)
            return true
        }
        
        func fire(at coordinate: (x: Int, y: Int)) -> Bool {
            let button = gridButtons[coordinate.x][coordinate.y]
            if button.tag == 1 {
                button.backgroundColor = UIColor.red
                button.isEnabled = false
                return true
            } else {
                button.backgroundColor = UIColor.blue
                button.isEnabled = false
                return false
            }
        }
    func isAllShipsDown() -> Bool{
        var allShips = true
        for ship in ships{
            for coordinate in ship.coordinates{
                var button = gridButtons[coordinate.x][coordinate.y]
                if(button.backgroundColor != UIColor.red){
                    allShips = false
                }
            }
        }
        return allShips
    }
    
    
//    func resultAlert(title: String){
//        
//        let message = "all ships have been found"
//        
//        let ac = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
//        ac.addAction(UIAlertAction(title: "Restart", style: .default, handler: { (_) in
//            self.resetGrid()
//        }))
//        self.present(ac, animated: true)
//    }
    
    func resetGrid(){
        for i in 0...9{
            for j in 0...9{
                var button = gridButtons[i][j]
                button.isEnabled = true
                button.backgroundColor = UIColor.white
            }
        }
            
        
        
    }
    func findCoordinates(sender: UIButton) -> (Int, Int){
        
        if let label = sender.titleLabel?.text{
            if label.first == "a"{
                if label.last == "0"{
                    return (0, 9)
                }
                else if label.last == "1"{
                    return (0, 0)
                    
                }
                else if label.last == "2"{
                    return (0,1)
                }
                else if label.last == "3"{
                    return (0,2)
                }
                else if label.last == "4"{
                    return (0,3)
                }
                else if label.last == "5"{
                    return (0,4)
                }
                else if label.last == "6"{
                    return (0,5)
                }
                else if label.last == "7"{
                    return (0,6)
                }
                else if label.last == "8"{
                    return(0,7)
                }
                else if label.last == "9"{
                    return (0,8)
                }
                
            }
            else if label.first == "b"{
                if label.last == "0"{
                    return (1, 9)
                }
                else if label.last == "1"{
                    return (1, 0)
                }
                else if label.last == "2"{
                    return (1,1)
                }
                else if label.last == "3"{
                    return (1,2)
                }
                else if label.last == "4"{
                    return (1,3)
                }
                else if label.last == "5"{
                    return (1,4)
                }
                else if label.last == "6"{
                    return (1,5)
                }
                else if label.last == "7"{
                    return (1,6)
                }
                else if label.last == "8"{
                    return(1,7)
                }
                else if label.last == "9"{
                    return (1,8)
                }

            }
            else if label.first == "c"{
                if label.last == "0"{
                    return (2, 9)
                }
                else if label.last == "1"{
                    return (2, 0)
                    
                }
                else if label.last == "2"{
                    return (2,1)
                }
                else if label.last == "3"{
                    return (2,2)
                }
                else if label.last == "4"{
                    return (2,3)
                }
                else if label.last == "5"{
                    return (2,4)
                }
                else if label.last == "6"{
                    return (2,5)
                }
                else if label.last == "7"{
                    return (2,6)
                }
                else if label.last == "8"{
                    return(2,7)
                }
                else if label.last == "9"{
                    return (2,8)
                }

            }
            else if label.first == "d"{
                if label.last == "0"{
                    return (3, 9)
                }
                else if label.last == "1"{
                    return (3, 0)
                    
                }
                else if label.last == "2"{
                    return (3,1)
                }
                else if label.last == "3"{
                    return (3,2)
                }
                else if label.last == "4"{
                    return (3,3)
                }
                else if label.last == "5"{
                    return (3,4)
                }
                else if label.last == "6"{
                    return (3,5)
                }
                else if label.last == "7"{
                    return (3,6)
                }
                else if label.last == "8"{
                    return(3,7)
                }
                else if label.last == "9"{
                    return (3,8)
                }

            }
            else if label.first == "e"{
                if label.last == "0"{
                    return (4, 9)
                }
                else if label.last == "1"{
                    return (4, 0)
                    
                }
                else if label.last == "2"{
                    return (4,1)
                }
                else if label.last == "3"{
                    return (4,2)
                }
                else if label.last == "4"{
                    return (4,3)
                }
                else if label.last == "5"{
                    return (4,4)
                }
                else if label.last == "6"{
                    return (4,5)
                }
                else if label.last == "7"{
                    return (4,6)
                }
                else if label.last == "8"{
                    return(4,7)
                }
                else if label.last == "9"{
                    return (4,8)
                }

            }
            else if label.first == "f"{
                if label.last == "0"{
                    return (5, 9)
                }
                else if label.last == "1"{
                    return (5, 0)
                    
                }
                else if label.last == "2"{
                    return (5,1)
                }
                else if label.last == "3"{
                    return (5,2)
                }
                else if label.last == "4"{
                    return (5,3)
                }
                else if label.last == "5"{
                    return (5,4)
                }
                else if label.last == "6"{
                    return (5,5)
                }
                else if label.last == "7"{
                    return (5,6)
                }
                else if label.last == "8"{
                    return(5,7)
                }
                else if label.last == "9"{
                    return (5,8)
                }

            }
            else if label.first == "g"{
                if label.last == "0"{
                    return (6, 9)
                }
                else if label.last == "1"{
                    return (6, 0)
                    
                }
                else if label.last == "2"{
                    return (6,1)
                }
                else if label.last == "3"{
                    return (6,2)
                }
                else if label.last == "4"{
                    return (6,3)
                }
                else if label.last == "5"{
                    return (6,4)
                }
                else if label.last == "6"{
                    return (6,5)
                }
                else if label.last == "7"{
                    return (6,6)
                }
                else if label.last == "8"{
                    return(6,7)
                }
                else if label.last == "9"{
                    return (6,8)
                }

            }
            else if label.first == "h"{
                if label.last == "0"{
                    return (7, 9)
                }
                else if label.last == "1"{
                    return (7, 0)
                    
                }
                else if label.last == "2"{
                    return (7,1)
                }
                else if label.last == "3"{
                    return (7,2)
                }
                else if label.last == "4"{
                    return (7,3)
                }
                else if label.last == "5"{
                    return (7,4)
                }
                else if label.last == "6"{
                    return (7,5)
                }
                else if label.last == "7"{
                    return (7,6)
                }
                else if label.last == "8"{
                    return(7,7)
                }
                else if label.last == "9"{
                    return (7,8)
                }

            }
            else if label.first == "i"{
                if label.last == "0"{
                    return (8, 9)
                }
                else if label.last == "1"{
                    return (8, 0)
                    
                }
                else if label.last == "2"{
                    return (8,1)
                }
                else if label.last == "3"{
                    return (8,2)
                }
                else if label.last == "4"{
                    return (8,3)
                }
                else if label.last == "5"{
                    return (8,4)
                }
                else if label.last == "6"{
                    return (8,5)
                }
                else if label.last == "7"{
                    return (8,6)
                }
                else if label.last == "8"{
                    return(8,7)
                }
                else if label.last == "9"{
                    return (8,8)
                }

            }
            else if label.first == "j"{
                if label.last == "0"{
                    return (9, 9)
                }
                else if label.last == "1"{
                    return (9, 0)
                    
                }
                else if label.last == "2"{
                    return (9,1)
                }
                else if label.last == "3"{
                    return (9,2)
                }
                else if label.last == "4"{
                    return (9,3)
                }
                else if label.last == "5"{
                    return (9,4)
                }
                else if label.last == "6"{
                    return (9,5)
                }
                else if label.last == "7"{
                    return (9,6)
                }
                else if label.last == "8"{
                    return(9,7)
                }
                else if label.last == "9"{
                    return (9,8)
                }

            }
            
//
        }
        return (-1, -1)
    }
}
