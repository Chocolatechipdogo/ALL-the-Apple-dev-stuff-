//
//  ViewController.swift
//  BattleShipStudy
//
//  Created by csuftitan on 5/14/23.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet var a1: UIButton!
    @IBOutlet var a2: UIButton!
    @IBOutlet var a3: UIButton!
    @IBOutlet var a4: UIButton!
    @IBOutlet var a5: UIButton!
    @IBOutlet var a6: UIButton!
    @IBOutlet var a7: UIButton!
    @IBOutlet var a8: UIButton!
    @IBOutlet var a9: UIButton!
    @IBOutlet var a10: UIButton!
    
    @IBOutlet var b1: UIButton!
    @IBOutlet var b2: UIButton!
    @IBOutlet var b3: UIButton!
    @IBOutlet var b4: UIButton!
    @IBOutlet var b5: UIButton!
    @IBOutlet var b6: UIButton!
    @IBOutlet var b7: UIButton!
    @IBOutlet var b8: UIButton!
    @IBOutlet var b9: UIButton!
    @IBOutlet var b10: UIButton!
    
    @IBOutlet var c1: UIButton!
    @IBOutlet var c2: UIButton!
    @IBOutlet var c3: UIButton!
    @IBOutlet var c4: UIButton!
    @IBOutlet var c5: UIButton!
    @IBOutlet var c6: UIButton!
    @IBOutlet var c7: UIButton!
    @IBOutlet var c8: UIButton!
    @IBOutlet var c9: UIButton!
    @IBOutlet var c10: UIButton!
    
    @IBOutlet var d1: UIButton!
    @IBOutlet var d2: UIButton!
    @IBOutlet var d3: UIButton!
    @IBOutlet var d4: UIButton!
    @IBOutlet var d5: UIButton!
    @IBOutlet var d6: UIButton!
    @IBOutlet var d7: UIButton!
    @IBOutlet var d8: UIButton!
    @IBOutlet var d9: UIButton!
    @IBOutlet var d10: UIButton!
    
    @IBOutlet var e1: UIButton!
    @IBOutlet var e2: UIButton!
    @IBOutlet var e3: UIButton!
    @IBOutlet var e4: UIButton!
    @IBOutlet var e5: UIButton!
    @IBOutlet var e6: UIButton!
    @IBOutlet var e7: UIButton!
    @IBOutlet var e8: UIButton!
    @IBOutlet var e9: UIButton!
    @IBOutlet var e10: UIButton!
    
    @IBOutlet var f1: UIButton!
    @IBOutlet var f2: UIButton!
    @IBOutlet var f3: UIButton!
    @IBOutlet var f4: UIButton!
    @IBOutlet var f5: UIButton!
    @IBOutlet var f6: UIButton!
    @IBOutlet var f7: UIButton!
    @IBOutlet var f8: UIButton!
    @IBOutlet var f9: UIButton!
    @IBOutlet var f10: UIButton!
    
    @IBOutlet var g1: UIButton!
    @IBOutlet var g2: UIButton!
    @IBOutlet var g3: UIButton!
    @IBOutlet var g4: UIButton!
    @IBOutlet var g5: UIButton!
    @IBOutlet var g6: UIButton!
    @IBOutlet var g7: UIButton!
    @IBOutlet var g8: UIButton!
    @IBOutlet var g9: UIButton!
    @IBOutlet var g10: UIButton!
    
    @IBOutlet var h1: UIButton!
    @IBOutlet var h2: UIButton!
    @IBOutlet var h3: UIButton!
    @IBOutlet var h4: UIButton!
    @IBOutlet var h5: UIButton!
    @IBOutlet var h6: UIButton!
    @IBOutlet var h7: UIButton!
    @IBOutlet var h8: UIButton!
    @IBOutlet var h9: UIButton!
    @IBOutlet var h10: UIButton!
    
    @IBOutlet var i1: UIButton!
    @IBOutlet var i2: UIButton!
    @IBOutlet var i3: UIButton!
    @IBOutlet var i4: UIButton!
    @IBOutlet var i5: UIButton!
    @IBOutlet var i6: UIButton!
    @IBOutlet var i7: UIButton!
    @IBOutlet var i8: UIButton!
    @IBOutlet var i9: UIButton!
    @IBOutlet var i10: UIButton!
    
    @IBOutlet var j1: UIButton!
    @IBOutlet var j2: UIButton!
    @IBOutlet var j3: UIButton!
    @IBOutlet var j4: UIButton!
    @IBOutlet var j5: UIButton!
    @IBOutlet var j6: UIButton!
    @IBOutlet var j7: UIButton!
    @IBOutlet var j8: UIButton!
    @IBOutlet var j9: UIButton!
    @IBOutlet var j10: UIButton!
   
    var gridButtons = [[UIButton]]()
    
    var gameController: GameController!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        initGrid()
        
        gameController = GameController(gridButtons: gridButtons)
        
        placeShips()
    }
    
    func initGrid(){
        gridButtons.append([a1,a2,a3,a4,a5,a6,a7,a8,a9,a10])
        gridButtons.append([b1,b2,b3,b4,b5,b6,b7,b8,b9,b10])
        gridButtons.append([c1,c2,c3,c4,c5,c6,c7,c8,c9,c10])
        gridButtons.append([d1,d2,d3,d4,d5,d6,d7,d8,d9,d10])
        gridButtons.append([e1,e2,e3,e4,e5,e6,e7,e8,e9,e10])
        gridButtons.append([f1,f2,f3,f4,f5,f6,f7,f8,f9,f10])
        gridButtons.append([g1,g2,g3,g4,g5,g6,g7,g8,g9,g10])
        gridButtons.append([h1,h2,h3,h4,h5,h6,h7,h8,h9,h10])
        gridButtons.append([i1,i2,i3,i4,i5,i6,i7,i8,i9,i10])
        gridButtons.append([j1,j2,j3,j4,j5,j6,j7,j8,j9,j10])

    }
    
    func placeShips (){
        var ship = Ship(length: 3, coordinates: [(0, 0), (0, 1), (0, 2)])
        
        let placed = gameController.placeShip(ship)
                
    }
    
    
    func resultAlert(title: String){
        
        let message = "all ships have been found"
        
        let ac = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        ac.addAction(UIAlertAction(title: "Restart", style: .default, handler: { (_) in
            self.gameController.resetGrid()
        }))
        self.present(ac, animated: true)
    }
    
    @IBAction func fireButtonPressed(_ sender: UIButton) {
//        if let buttonLabel = sender.titleLabel?.text{
//            print(buttonLabel.first)
//            if (buttonLabel.first == "a"){
//                let lastElem =
//            }
//        }
//        print (sender.tag)
//        print ("the tag is above this")
//        let coordinate = (sender.tag / 10, sender.tag % 10)
        let coordinate = gameController.findCoordinates(sender: sender)
        if (coordinate == (-1,-1)){
            print ("Error will occur")
        }
        let hit = gameController.fire(at: coordinate)
        if hit {
            print("ship has been hit")
            if(gameController.isAllShipsDown()){
                self.resultAlert(title: "YOU FOUND THEM ALL")
            }
        }
    }


}

