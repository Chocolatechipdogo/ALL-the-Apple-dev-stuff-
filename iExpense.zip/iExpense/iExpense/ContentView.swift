//
//  ContentView.swift
//  iExpense
//
//  Created by csuftitan on 4/12/23.
//

import SwiftUI

//class User: ObservableObject{
//   @Published var firstName = "Bilbo"
//   @Published var lastName = "Baggins"
//}
//section 1 class example
//struct User: Codable {
//    let firstName: String
//    let lastName: String
//}
//final section

struct ContentView: View {
    //    @StateObject var user = User()
    //    @State private var showingSheet = false
    //
    //    @State private var numbers = [Int]()
    //    @State private var currentNumber = 1
    //
    //    func removeRows(at offsets: IndexSet) {
    //        numbers.remove(atOffsets: offsets)
    //    }
    //part of the first commented section
    
    //    @State private var tapCount = UserDefaults.standard.integer(forKey: "Tap")
    //    @AppStorage ("TapCount") private var tapCount = 0
    //section 2
    
//    @State private var user = User(firstName: "Taylor", lastName: "Swift")
    //final section
    @StateObject var expenses = Expenses()
    @State private var showingAddExpense = false
    
    func removeItems(at offsets: IndexSet) {
        expenses.items.remove(atOffsets: offsets)
    }
    
    var body: some View {
        //        NavigationView{
        //            VStack {
        //                Text("Your name is \(user.firstName) \(user.lastName).")
        //
        //                TextField("First name", text: $user.firstName)
        //                    .padding()
        //                TextField("Last name", text: $user.lastName)
        //                    .padding()
        //
        //
        //                Button("Show Sheet") {
        //                    // show the sheet
        //                    showingSheet.toggle()
        //                }
        //                .padding()
        //                .sheet(isPresented: $showingSheet) {
        //                    // contents of the sheet
        //                    SecondView(name: "CHOCO")
        //                }
        //                List {
        //                    ForEach(numbers, id: \.self) {
        //                        Text("Row \($0)")
        //                    }
        //                    .onDelete(perform: removeRows)
        //
        //                }
        //
        //                Button("Add Number") {
        //                    numbers.append(currentNumber)
        //                    currentNumber += 1
        //                }
        //
        //            }
        //            .toolbar {
        //                EditButton()
        //            }
        //        }
        // above is a section
        
        //        Button("Tap count: \(tapCount)") {
        //                    tapCount += 1
        //         UserDefaults.standard.set(self.tapCount, forKey: "Tap")
        //                }
        //section 2
        
//        Button("Save User") {
//            let encoder = JSONEncoder()
//
//            if let data = try? encoder.encode(user) {
//                UserDefaults.standard.set(data, forKey: "UserData")
        //final section
//            }
//        }
        //final section
        NavigationView {
            List {
                ForEach(expenses.items) { item in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(item.name)
                                .font(.headline)
                            Text(item.type)
                        }

                        Spacer()
                        Text(item.amount, format: .currency(code: "USD"))
                    }
                }
                .onDelete(perform: removeItems)
            }
            .toolbar {
                Button {
                    showingAddExpense = true
                } label: {
                    Image(systemName: "plus")
                }
            }
            .navigationTitle("iExpense")
            .sheet(isPresented: $showingAddExpense) {
                AddView(expenses: expenses)
            }
            
        }
    }
}
    //struct SecondView: View {
    //    let name: String
    //    @Environment(\.dismiss) var dismiss
    //    var body: some View {
    //        Text("Hello, \(name)!")
    //            .padding(10)
    //        Button("Dismiss") {
    //            dismiss()
    //        }
    //    }
    //}
    //part of the 1 section commented out
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }

